#Arduino Timezone Library v1.0
https://github.com/JChristensen/Timezone  
LICENSE file  
Jack Christensen Mar 2012  

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)
##CC BY-SA
Arduino Timezone Library by Jack Christensen is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a letter to:  
Creative Commons  
444 Castro Street, Suite 900  
Mountain View, CA 94041  
